<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require 'vendor/autoload.php'; // Adjust the path accordingly

session_start();

define('OTP_EXPIRATION_TIME', 600); // 10 minutes in seconds

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Validate username and password (replace with your actual validation logic)
    if ($username === 'reditocapital' && $password === 'ElonMusk@321') {
        // Generate OTP and store it in the session along with the timestamp
        $otp = rand(100000, 999999);
        $otpTimestamp = time();
        $_SESSION['otp'] = $otp;
        $_SESSION['otp_timestamp'] = $otpTimestamp;

        // Send OTP via email
        sendOTPByEmail($username, $otp);

        // Redirect to OTP verification page
        header('Location: otp_verification.php');
        exit();
    } else {
        $loginError = 'Invalid username or password';
    }
}

function sendOTPByEmail($username, $otp) {
    $mail = new PHPMailer(true);

    try {
        $mail->isSMTP();
        $mail->Host       = 'smtp.hostinger.com';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'narendrapatidar@tripocio.com';
        $mail->Password   = 'Tripocio@1206'; 
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = 587; 

        $mail->setFrom('narendrapatidar@tripocio.com', 'narendra');
        $mail->addAddress('devnarendra280@gmail.com', 'Recipient Name');

        $mail->isHTML(true);
        $mail->Subject = 'User Login Request';
        $mail->Body    = 'Please approve login for user ' . $username . '. OTP: ' . $otp;

        $mail->send();
    } catch (Exception $e) {
        echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
    <title>Login</title>
</head>
<body>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title text-center mb-4">Login</h4>
                        <?php if (isset($loginError)) : ?>
                            <div class="alert alert-danger" role="alert">
                                <?php echo $loginError; ?>
                            </div>
                        <?php endif; ?>
                        <form id="loginForm" method="post" onsubmit="return validateForm()">
                            <div class="form-group">
                                <label for="username">Username:</label>
                                <input type="text" class="form-control" name="username" id="username" required>
                            </div>
                            <div class="form-group">
                                <label for="password">Password:</label>
                                <input type="password" class="form-control" name="password" id="password" required>
                            </div>
                            <button type="submit" class="btn btn-primary btn-block">Login</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
    <script>
        function validateForm() {
            // Basic client-side validation
            var username = document.getElementById("username").value;
            var password = document.getElementById("password").value;

            if (!username || !password) {
                alert("Please enter both username and password");
                return false;
            }

            return true;
        }
    </script>
</body>
</html>
