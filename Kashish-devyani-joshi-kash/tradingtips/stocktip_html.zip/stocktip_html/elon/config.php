<?php
$host = 'localhost';
$username = 'root';
$password = '';
$database = 'redito';
$mysqli = new mysqli($host, $username, $password, $database);

?>