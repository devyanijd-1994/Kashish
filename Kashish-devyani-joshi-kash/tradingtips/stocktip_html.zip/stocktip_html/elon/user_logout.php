<?php
session_start();

// Check if the user is logged in
if (!isset($_SESSION['authenticated'])) {
    header('Location: index.php');
    exit;
}

// Unset all session variables
$_SESSION = array();

// Destroy the session
session_destroy();

// Redirect to the login page
header('Location: index.php');
exit;
?>
