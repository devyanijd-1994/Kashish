<?php
session_start();

// Check if the user is authenticated
if (!isset($_SESSION['authenticated'])) {
   header('Location: index.php');
   exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Home Contact</title>
    <!-- Favicon and touch icons -->
    <link rel="shortcut icon" href="assets/dist/img/ico/favicon.png" type="image/x-icon">
    <!-- Bootstrap CSS -->
    <link href="assets/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
    <!-- Font Awesome -->
    <link href="assets/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css"/>
    <!-- DataTables CSS -->
    <link href="assets/plugins/datatables/dataTables.min.css" rel="stylesheet" type="text/css"/>
    <!-- Theme CSS -->
    <link href="assets/dist/css/stylecrm.css" rel="stylesheet" type="text/css"/>
</head>
<body class="hold-transition sidebar-mini">
    <div class="wrapper">
        <?php include('header.php'); ?>
        <div class="content-wrapper">
            <section class="content-header">
                <div class="header-icon">
                    <i class="fa fa-suitcase"></i>
                </div>
                <div class="header-title">
                    <h1>Contact Form</h1>
                    <small>List of Enquiry</small>
                </div>
            </section>
            <section class="content">
                <div class="row">
                    <div class="col-sm-12">
                        <div class="panel panel-bd lobidrag">
                            <div class="panel-heading">
                                <div class="btn-group" id="buttonexport">
                                    <a href="#">
                                        <h4>Enquiry</h4>
                                    </a>
                                    <center> <button id="copyButton">Copy Table Data</button></center>
                                </div>
                            </div>
                            <div class="panel-body">
                                <div class="table-responsive">
                                    <table id="dataTableExample1" class="table table-bordered table-striped table-hover">
                                        <?php
                                            include('config.php');
                                            $sql = "select * from redito_inquery ORDER BY id DESC ";
                                            $result = $mysqli->query($sql);
                                            if ($result->num_rows > 0) {
                                                echo "
                                                    <thead>
                                                        <tr class='info'>
                                                            <th>Sl. No.   </th>
                                                            <th>Name </th>
                                                            <th>Mobile Number </th>
                                                            <th>Whatsapp </th>
                                                            <th>Email  </th>
                                                            <th>Segment  </th>
                                                            <th>City </th>
                                                            <th>Time & Date </th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>";
                                                while ($row = $result->fetch_assoc()) {
                                                    echo "     
                                                        <tr>
                                                            <td>".$row['id']."</td>
                                                            <td>".$row['name']."</td>
                                                            <td>".$row['number']."</td>
                                                            <td><center><a href='https://api.whatsapp.com/send?phone=".$row['number']."'><i class='fa fa-whatsapp' style='font-size:36px'></i></a></center></td>
                                                            <td>".$row['email']."</td>
                                                            <td>".$row['segment']."</td>
                                                            <td>".$row['location']."</td>
                                                            <td>".$row['datetime']."</td>
                                                        </tr>";
                                                }
                                                echo "</tbody>";
                                            }
                                            $total = mysqli_num_rows($result);
                                        ?>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
        <footer class="main-footer">
            <strong>Copyright &copy; 2023 <a href="#">Redito Capital</a>.</strong> All rights reserved.
        </footer>
    </div>

    <!-- JavaScript Libraries -->
    <script src="assets/plugins/jQuery/jquery-1.12.4.min.js" type="text/javascript"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
    <script src="assets/plugins/datatables/dataTables.min.js" type="text/javascript"></script>

    <!-- DataTables Configuration -->
    <script>
        $(document).ready(function () {
            var table = $('#dataTableExample1').DataTable({
                order: [[0, 'desc']],
                lengthMenu: [20, 50, 200, 500],
                pageLength: 20
            });

            // Function to copy the table data when the button is clicked
            function copyTableData() {
                var rows = table.rows({ selected: true }).data();
                var copiedData = "";

                for (var i = 0; i < rows.length; i++) {
                    copiedData += rows[i].join("\t") + "\n";
                }

                navigator.clipboard.writeText(copiedData)
                    .then(() => alert("Table data copied to clipboard!"))
                    .catch(error => console.error("Error copying to clipboard:", error));
            }

            // Add click event listener to the copy button
            document.getElementById("copyButton").addEventListener("click", copyTableData);
        });
    </script>
</body>
</html>
