<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
    <title>OTP Verification</title>
</head>
<body>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title text-center mb-4">OTP Verification</h4>

                        <?php
                        session_start();
                        define('OTP_EXPIRATION_TIME', 600);

                        // Check if the form is submitted
                        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                            // Retrieve the user-entered OTP from the form
                            $enteredOtp = $_POST['otp'];

                            // Retrieve the generated OTP and timestamp from the session
                            $otp = $_SESSION['otp'];
                            $otpTimestamp = $_SESSION['otp_timestamp'];

                            // Check if the OTP is still valid based on the expiration time
                            if ($enteredOtp == $otp && (time() - $otpTimestamp) <= OTP_EXPIRATION_TIME) {
                                // OTP is valid, redirect to the user's dashboard (replace with your actual dashboard URL)
                                header('Location: dashboard.php');
                                exit();
                            } else {
                                // Invalid OTP or expired, display an error message
                                echo '<div class="alert alert-danger" role="alert">Invalid OTP or expired. Please try again.</div>';
                            }
                        }
                        ?>

                        <form action="" method="post">
                            <div class="form-group">
                                <label for="otp">Enter OTP:</label>
                                <input type="text" class="form-control" name="otp" required>
                            </div>
                            <button type="submit" class="btn btn-primary btn-block">Verify OTP</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</body>
</html>
