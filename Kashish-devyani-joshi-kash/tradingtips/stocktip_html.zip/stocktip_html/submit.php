<?php
$host = 'localhost';
$username = 'root';
$password = '';
$database = 'redito';
$mysqli = new mysqli($host, $username, $password, $database);
function getUserLocation() {
    $ip = $_SERVER['REMOTE_ADDR'];
    $url = "http://ipinfo.io/{$ip}/json";
    $response = file_get_contents($url);
    $data = json_decode($response, true);

    // Extract city name or other relevant information
    $city = isset($data['city']) ? $data['city'] : '';
    $country = isset($data['country']) ? $data['country'] : '';
    $region = isset($data['region']) ? $data['region'] : '';

    return $city . ', ' . $country . ',' . $region;
}

if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

$name = $_POST["name"];
$number = $_POST["number"];
$email = $_POST["email"];
$segment = $_POST["segment"];

$userLocation = getUserLocation();
$sql = "INSERT INTO redito_inquery (name, number, email, segment,location) VALUES ('$name', '$number', '$email', '$segment','$userLocation')";

if ($mysqli->query($sql) === TRUE) {
    
    header("Location: thank_you.html");
    exit(); 
} else {
    echo "Error: " . $sql . "<br>" . $mysqli->error;
}

$mysqli->close();
?>
