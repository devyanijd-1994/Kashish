<?php
session_start();

// Function to get user location using GeoPlugin
function getUserLocation() {
    $ip = $_SERVER['REMOTE_ADDR'];
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        $ip = $_SERVER['HTTP_CLIENT_IP'];
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
    }

    // Ensure the IP address is URL-encoded
    $ip = urlencode($ip);
    
    $url = "http://www.geoplugin.net/json.gp?ip={$ip}";
    $response = file_get_contents($url);

    if ($response === FALSE) {
        die('Error fetching GeoPlugin data');
    }

    $data = json_decode($response, true);

    if ($data === NULL) {
        die('Error decoding JSON response');
    }

    // Log the API response for debugging
    error_log(print_r($data, true));

    // Extract city, region, and country information
    $city = isset($data['geoplugin_city']) ? $data['geoplugin_city'] : 'Unknown';
    $region = isset($data['geoplugin_region']) ? $data['geoplugin_region'] : 'Unknown';
    $country = isset($data['geoplugin_countryName']) ? $data['geoplugin_countryName'] : 'Unknown';

    return ['city' => $city, 'region' => $region, 'country' => $country];
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Retrieve the form data
    $name = $_POST['name'];
    $number = $_POST['number'];
    $email = $_POST['email'];
    $segment = isset($_POST['segment']) ? implode(", ", $_POST['segment']) : '';

    // Get user location using the function
    $locationData = getUserLocation();
    $location = $locationData['city'] . ', ' . $locationData['region'] . ', ' . $locationData['country'];

    // Set the timezone and get current date and time
    date_default_timezone_set('Asia/Kolkata');
    $date_and_time = date('Y-m-d h:i:s A');

    // Database connection
    $servername = "localhost";
    $username = "u867331264_kashish";
    $password = "n*U6!dv#"; 
    $dbname = "u867331264_kashish"; 
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        $_SESSION['error'] = "Connection failed: " . $conn->connect_error;
        header('Location: https://kashishjoshiresearch.com/intraday-trading-calls');
        exit;
    }

    // Check for duplicates
    $stmt = $conn->prepare("SELECT id FROM intraday WHERE email = ? OR number = ?");
    $stmt->bind_param("ss", $email, $number);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        // Duplicate entry found
        $_SESSION['error_message'] = "Duplicate entry found. The email or phone number already exists.";
        $stmt->close();
        $conn->close();
        header('Location: https://kashishjoshiresearch.com/intraday-trading-calls');
        exit;
    } else {
        // Prepare and bind
        $stmt = $conn->prepare("INSERT INTO intraday (name, number, email, segment, location, date_and_time) 
                                VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssss", $name, $number, $email, $segment, $location, $date_and_time);

        // Execute the statement
        if ($stmt->execute()) {
            // Redirect to thankyou.html without any parameters
            header('Location: https://kashishjoshiresearch.com/tradingtips/thankyou.html');
            exit;
        } else {
            $_SESSION['error_message'] = "Error: " . $stmt->error;
        }

        $stmt->close();
    }

    $conn->close();
} else {
    // If the request method is not POST, return an error
    http_response_code(405);
    echo json_encode(array('message' => 'Method Not Allowed'));
    exit;
}
?>
